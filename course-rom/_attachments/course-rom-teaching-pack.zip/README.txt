M2 ROM & Data-Driven ROM — teaching material for sessions 1–14

Student experiments:
  Open the fourteen session*.ipynb files and the guided galerkin-sampling.ipynb in JupyterLab.
  Use requirements-course.txt for the tested Python environment (Python >= 3.12).
  Keep thermal-fin-coarse.npz beside the notebooks for sessions 13–14.
  Other experiment data are generated in the notebooks.
  *-starter.html contains executed starter cells and plots.

Website, notes and homework:
  python3 -m http.server 8080 --bind 127.0.0.1 --directory site
  Open http://127.0.0.1:8080/course-rom/index.html
  Follow the session pages for required notes, practicals and homework.
  MathJax normally loads from a CDN. The historical introduction PDF is included
  as an opening-session companion; it does not cover every new web chapter.

Submission dates and grading arrangements are announced by the instructor.
This package contains student material only; instructor checks/solutions are excluded.

POD chapter: run pod.ipynb with melencolia-magic-square.png beside it.
